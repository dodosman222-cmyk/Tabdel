// ====================================================================
// Tabdeel (تبديل) - Native Windows 7 / 8 / 10 / 11 C# Application
// Compiles natively using Windows Built-in compiler: csc.exe
// NO Python, NO AutoHotkey, NO downloads required!
// ====================================================================
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace TabdeelApp
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new TabdeelContext());
        }
    }

    public class TabdeelContext : ApplicationContext
    {
        private NotifyIcon trayIcon;
        private MessageForm hiddenForm;

        public TabdeelContext()
        {
            trayIcon = new NotifyIcon();
            trayIcon.Icon = SystemIcons.Application;
            trayIcon.Text = "Tabdeel (تبديل) - اختصار لوحة المفاتيح (F9) نشط";
            trayIcon.Visible = true;

            ContextMenu menu = new ContextMenu();
            menu.MenuItems.Add("برنامج تبديل يعمل بنجاح (F9)").Enabled = false;
            menu.MenuItems.Add("-");
            menu.MenuItems.Add("تعليمات الاستخدام", (s, e) => {
                trayIcon.ShowBalloonTip(3500, "طريقة الاستخدام", "ظلل النص المكتوب خطأ في أي برنامج (مثل المتصفح أو الوورد)، ثم اضغط على زر F9 وسيتم استبداله فوراً.", ToolTipIcon.Info);
            });
            menu.MenuItems.Add("-");
            menu.MenuItems.Add("إنهاء البرنامج (Exit)", (s, e) => {
                trayIcon.Visible = false;
                Application.Exit();
            });

            trayIcon.ContextMenu = menu;
            trayIcon.ShowBalloonTip(3500, "تطبيق تبديل جاهز", "البرنامج يعمل الآن في الخلفية بجانب الساعة! اضغط على زر (F9) لاستبدال النصوص المظللة.", ToolTipIcon.Info);

            hiddenForm = new MessageForm(trayIcon);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (trayIcon != null) trayIcon.Dispose();
                if (hiddenForm != null) hiddenForm.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    public class MessageForm : Form
    {
        [DllImport("user32.dll")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private const int HOTKEY_ID = 9001;
        private const int WM_HOTKEY = 0x0312;
        private NotifyIcon tray;

        private static readonly Dictionary<char, string> EnToAr = new Dictionary<char, string>();
        private static readonly Dictionary<char, string> ArToEn = new Dictionary<char, string>();

        static MessageForm()
        {
            InitMap();
        }

        public MessageForm(NotifyIcon trayIcon)
        {
            this.tray = trayIcon;
            this.ShowInTaskbar = false;
            this.WindowState = FormWindowState.Minimized;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Size = new Size(0, 0);

            // Register HotKey
            RegisterHotKey(this.Handle, HOTKEY_ID, 0, 0x78);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID)
            {
                ConvertSelection();
            }
            base.WndProc(ref m);
        }

        private void ConvertSelection()
        {
            try
            {
                // Send Ctrl+C to copy highlighted text
                SendKeys.SendWait("^c");
                Thread.Sleep(80);

                if (!Clipboard.ContainsText())
                {
                    tray.ShowBalloonTip(2000, "تنبيه تبديل", "يرجى تظليل النص المكتوب خطأ أولاً ثم الضغط على الزر.", ToolTipIcon.Warning);
                    return;
                }

                string raw = Clipboard.GetText();
                if (string.IsNullOrEmpty(raw)) return;

                string converted = Transform(raw);
                Clipboard.SetText(converted);
                Thread.Sleep(50);

                // Send Ctrl+V to paste converted text
                SendKeys.SendWait("^v");
                System.Media.SystemSounds.Asterisk.Play();
            }
            catch {}
        }

        private string Transform(string text)
        {
            int enCount = 0;
            int arCount = 0;
            foreach (char c in text)
            {
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) enCount++;
                else if (c >= 0x0600 && c <= 0x06FF) arCount++;
            }

            bool toArabic = enCount >= arCount;
            StringBuilder sb = new StringBuilder();

            if (toArabic)
            {
                foreach (char c in text)
                {
                    if (EnToAr.ContainsKey(c)) sb.Append(EnToAr[c]);
                    else sb.Append(c);
                }
            }
            else
            {
                string s = text.Replace("لا", "b").Replace("لآ", "B").Replace("لأ", "G").Replace("لإ", "T");
                foreach (char c in s)
                {
                    if (ArToEn.ContainsKey(c)) sb.Append(ArToEn[c]);
                    else sb.Append(c);
                }
            }
            return sb.ToString();
        }

        private static void InitMap()
        {
            char[] en = new char[] {
                (char)0x60, '~',
                'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']',
                'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', (char)0x27,
                'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/',
                'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}',
                'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"',
                'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?'
            };

            string[] ar = new string[] {
                "ذ", "ّ",
                "ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د",
                "ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط",
                "ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ",
                "َ", "ً", "ُ", "ٌ", "لإ", "إ", "‘", "÷", "×", "؛", "<", ">",
                "ِ", "ٍ", "]", "[", "لأ", "أ", "ـ", "،", "/", ":", "\"",
                "~", "ْ", "}", "{", "لآ", "آ", "’", ",", ".", "؟"
            };

            for (int i = 0; i < en.Length && i < ar.Length; i++)
            {
                char eChar = en[i];
                string aStr = ar[i];
                EnToAr[eChar] = aStr;
                if (aStr.Length == 1 && !ArToEn.ContainsKey(aStr[0]))
                {
                    ArToEn[aStr[0]] = eChar.ToString();
                }
            }

            ArToEn['ذ'] = ((char)0x60).ToString();
            ArToEn['،'] = "K";
            ArToEn['؛'] = "P";
            ArToEn['؟'] = "?";
            ArToEn['ء'] = "x";
            ArToEn['ئ'] = "z";
            ArToEn['ؤ'] = "c";
            ArToEn['إ'] = "Y";
            ArToEn['أ'] = "H";
            ArToEn['آ'] = "N";
            ArToEn['ة'] = "m";
            ArToEn['ى'] = "n";
            ArToEn['ي'] = "d";
            ArToEn['ـ'] = "J";
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            UnregisterHotKey(this.Handle, HOTKEY_ID);
            base.OnFormClosing(e);
        }
    }
}
