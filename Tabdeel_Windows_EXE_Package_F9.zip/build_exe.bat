@echo off
setlocal enabledelayedexpansion
title Building Tabdeel.exe for Windows 7 / 8 / 10 / 11
echo ========================================================================
echo   Building Native Tabdeel.exe (Windows 7 / 8 / 10 / 11 Compatible)
echo ========================================================================
echo.

:: 1. Search for built-in Windows C# compiler (csc.exe) pre-installed on Windows 7
set CSC=""
if exist "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe" set CSC="%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if !CSC!=="" if exist "%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set CSC="%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if !CSC!=="" if exist "%SystemRoot%\Microsoft.NET\Framework\v3.5\csc.exe" set CSC="%SystemRoot%\Microsoft.NET\Framework\v3.5\csc.exe"
if !CSC!=="" if exist "%SystemRoot%\Microsoft.NET\Framework\v2.0.50727\csc.exe" set CSC="%SystemRoot%\Microsoft.NET\Framework\v2.0.50727\csc.exe"

if not !CSC!=="" (
    echo [FOUND] Windows Built-in .NET Compiler: !CSC!
    echo Compiling Tabdeel.exe directly using Windows built-in tools...
    echo Please wait 3 seconds...
    !CSC! /nologo /target:winexe /platform:anycpu /out:Tabdeel.exe Tabdeel.cs
    if !errorlevel! equ 0 if exist "Tabdeel.exe" (
        echo.
        echo ========================================================================
        echo   [SUCCESS!] Tabdeel.exe has been generated successfully!
        echo   No external tools needed. 100%% works on Windows 7!
        echo ========================================================================
        echo.
        echo Starting Tabdeel.exe in your System Tray now...
        start "" "Tabdeel.exe"
        echo Application is running beside the clock! Press [F9] to test.
        pause
        exit /b 0
    ) else (
        echo.
        echo ========================================================================
        echo   [ERROR] Compilation failed.
        echo ========================================================================
        pause
        exit /b 1
    )
)

:: 2. Fallback to AutoHotkey
if exist "%ProgramFiles%\AutoHotkey\Compiler\Ahk2Exe.exe" (
    echo Compiling AutoHotkey script...
    "%ProgramFiles%\AutoHotkey\Compiler\Ahk2Exe.exe" /in "Tabdeel_Switcher.ahk" /out "Tabdeel.exe"
    echo [SUCCESS] Tabdeel.exe generated via AutoHotkey!
    start "" "Tabdeel.exe"
    pause
    exit /b 0
)

echo [INFO] You can also run Tabdeel_Switcher.ahk directly with AutoHotkey installed.
pause
