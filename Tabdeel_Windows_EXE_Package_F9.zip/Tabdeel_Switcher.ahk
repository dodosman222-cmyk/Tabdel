; ====================================================================
; Tabdeel (تبديل) - Windows Global Keyboard Layout Switcher
; Automatically converts mistyped text between Arabic & English layouts
; Works anywhere on Windows: Chrome, ChatGPT, Word, Telegram, Notepad, etc.
; ====================================================================
#Requires AutoHotkey v2.0
#SingleInstance Force

; Set tray icon and tooltip
A_IconTip := "Tabdeel - Arabic/English Layout Switcher (F9)"
TraySetIcon("shell32.dll", 44)

; Create mapping dictionaries
global EN_TO_AR := Map(
    "q", "ض", "w", "ص", "e", "ث", "r", "ق", "t", "ف", "y", "غ", "u", "ع", "i", "ه", "o", "خ", "p", "ح", "[", "ج", "]", "د",
    "a", "ش", "s", "س", "d", "ي", "f", "ب", "g", "ل", "h", "ا", "j", "ت", "k", "ن", "l", "م", ";", "ك", "'", "ط",
    "z", "ئ", "x", "ء", "c", "ؤ", "v", "ر", "b", "لا", "n", "ى", "m", "ة", ",", "و", ".", "ز", "/", "ظ", "`", "ذ",
    "Q", "َ", "W", "ً", "E", "ُ", "R", "ٌ", "T", "لإ", "Y", "إ", "U", "‘", "I", "÷", "O", "×", "P", "؛", "{", "<", "}", ">",
    "A", "ِ", "S", "ٍ", "D", "]", "F", "[", "G", "لأ", "H", "أ", "J", "ـ", "K", "،", "L", "/", ":", ":", '"', '"',
    "Z", "~", "X", "ْ", "C", "}", "V", "{", "B", "لآ", "N", "آ", "M", "’", "<", ",", ">", ".", "?", "؟", "~", "ّ"
)

global AR_TO_EN := Map(
    "ض", "q", "ص", "w", "ث", "e", "ق", "r", "ف", "t", "غ", "y", "ع", "u", "ه", "i", "خ", "o", "ح", "p", "ج", "[", "د", "]",
    "ش", "a", "س", "s", "ي", "d", "ب", "f", "ل", "g", "ا", "h", "ت", "j", "ن", "k", "م", "l", "ك", ";", "ط", "'",
    "ئ", "z", "ء", "x", "ؤ", "c", "ر", "v", "ى", "n", "ة", "m", "و", ",", "ز", ".", "ظ", "/", "ذ", "`",
    "َ", "Q", "ً", "W", "ُ", "E", "ٌ", "R", "إ", "Y", "‘", "U", "÷", "I", "×", "O", "؛", "P",
    "ِ", "A", "ٍ", "S", "أ", "H", "ـ", "J", "،", "K",
    "ْ", "X", "آ", "N", "’", "M", "؟", "?", "ّ", "~"
)

; Register the Global Windows Shortcut
F9::
{
    ; Preserve original clipboard content
    oldClip := ClipboardAll()
    A_Clipboard := ""

    ; Send Ctrl+C to copy currently highlighted text
    Send("^c")

    ; Wait up to 300ms for clipboard content
    if !ClipWait(0.3) {
        TrayTip("Tabdeel", "يرجى تظليل النص أولاً ثم الضغط على F9", 1)
        A_Clipboard := oldClip
        return
    }

    selectedText := A_Clipboard
    convertedText := ConvertText(selectedText)

    ; Replace clipboard with converted text and paste
    A_Clipboard := convertedText
    Send("^v")

    ; Play a subtle confirmation click
    SoundBeep(850, 40)

    ; Restore original clipboard after a short pause
    Sleep(150)
    A_Clipboard := oldClip
}

ConvertText(txt) {
    enCount := 0
    arCount := 0
    loop parse, txt {
        if RegExMatch(A_LoopField, "[a-zA-Z]")
            enCount++
        else if RegExMatch(A_LoopField, "[\\x{0600}-\\x{06FF}]")
            arCount++
    }

    toArabic := (enCount >= arCount)
    out := ""

    if (toArabic) {
        loop parse, txt {
            ch := A_LoopField
            if EN_TO_AR.Has(ch)
                out .= EN_TO_AR[ch]
            else
                out .= ch
        }
    } else {
        txt := StrReplace(txt, "لا", "b")
        txt := StrReplace(txt, "لآ", "B")
        txt := StrReplace(txt, "لأ", "G")
        txt := StrReplace(txt, "لإ", "T")

        loop parse, txt {
            ch := A_LoopField
            if AR_TO_EN.Has(ch)
                out .= AR_TO_EN[ch]
            else
                out .= ch
        }
    }
    return out
}