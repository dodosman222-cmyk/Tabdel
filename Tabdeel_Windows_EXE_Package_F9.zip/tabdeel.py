import time
import keyboard
import pyperclip

# ====================================================================
# Tabdeel (تبديل) - Python Windows Global Layout Switcher
# Compiles to standalone .exe via PyInstaller
# ====================================================================

EN_TO_AR = {
    "`": "ذ",
    "~": "ّ",
    "!": "!",
    "@": "@",
    "#": "#",
    "$": "$",
    "%": "%",
    "^": "^",
    "&": "&",
    "*": "*",
    "(": ")",
    ")": "(",
    "-": "-",
    "_": "_",
    "=": "=",
    "+": "+",
    "q": "ض",
    "Q": "َ",
    "w": "ص",
    "W": "ً",
    "e": "ث",
    "E": "ُ",
    "r": "ق",
    "R": "ٌ",
    "t": "ف",
    "T": "لإ",
    "y": "غ",
    "Y": "إ",
    "u": "ع",
    "U": "‘",
    "i": "ه",
    "I": "÷",
    "o": "خ",
    "O": "×",
    "p": "ح",
    "P": "؛",
    "[": "ج",
    "{": "<",
    "]": "د",
    "}": ">",
    "\\": "\\",
    "|": "|",
    "a": "ش",
    "A": "ِ",
    "s": "س",
    "S": "ٍ",
    "d": "ي",
    "D": "]",
    "f": "ب",
    "F": "[",
    "g": "ل",
    "G": "لأ",
    "h": "ا",
    "H": "أ",
    "j": "ت",
    "J": "ـ",
    "k": "ن",
    "K": "،",
    "l": "م",
    "L": "/",
    ";": "ك",
    ":": ":",
    "'": "ط",
    "\"": "\"",
    "z": "ئ",
    "Z": "~",
    "x": "ء",
    "X": "ْ",
    "c": "ؤ",
    "C": "}",
    "v": "ر",
    "V": "{",
    "b": "لا",
    "B": "لآ",
    "n": "ى",
    "N": "آ",
    "m": "ة",
    "M": "’",
    ",": "و",
    "<": ",",
    ".": "ز",
    ">": ".",
    "/": "ظ",
    "?": "؟"
}

AR_TO_EN = {
    "ذ": "`",
    "ّ": "~",
    "!": "!",
    "@": "@",
    "#": "#",
    "$": "$",
    "%": "%",
    "^": "^",
    "&": "&",
    "*": "*",
    ")": "(",
    "(": ")",
    "-": "-",
    "_": "_",
    "=": "=",
    "+": "+",
    "ض": "q",
    "َ": "Q",
    "ص": "w",
    "ً": "W",
    "ث": "e",
    "ُ": "E",
    "ق": "r",
    "ٌ": "R",
    "ف": "t",
    "غ": "y",
    "إ": "Y",
    "ع": "u",
    "‘": "U",
    "ه": "i",
    "÷": "I",
    "خ": "o",
    "×": "O",
    "ح": "p",
    "؛": "P",
    "ج": "[",
    "<": "{",
    "د": "]",
    ">": "}",
    "\\": "\\",
    "|": "|",
    "ش": "a",
    "ِ": "A",
    "س": "s",
    "ٍ": "S",
    "ي": "d",
    "]": "D",
    "ب": "f",
    "[": "F",
    "ل": "g",
    "ا": "h",
    "أ": "H",
    "ت": "j",
    "ـ": "J",
    "ن": "k",
    "،": "K",
    "م": "l",
    "/": "L",
    "ك": ";",
    ":": ":",
    "ط": "'",
    "\"": "\"",
    "ئ": "z",
    "~": "Z",
    "ء": "x",
    "ْ": "X",
    "ؤ": "c",
    "}": "C",
    "ر": "v",
    "{": "V",
    "ى": "n",
    "آ": "N",
    "ة": "m",
    "’": "M",
    "و": ",",
    ",": "<",
    "ز": ".",
    ".": ">",
    "ظ": "/",
    "؟": "?"
}
AR_LIGATURES = {
    "لا": "b",
    "لآ": "B",
    "لأ": "G",
    "لإ": "T"
}

def convert_layout(text):
    # Detect language direction
    en_count = sum(1 for c in text if c.isascii() and c.isalpha())
    ar_count = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
    
    if en_count >= ar_count:
        # Convert English typed keys -> Arabic
        return "".join(EN_TO_AR.get(c, c) for c in text)
    else:
        # Convert Arabic typed keys -> English
        for lig, repl in AR_LIGATURES.items():
            text = text.replace(lig, repl)
        return "".join(AR_TO_EN.get(c, c) for c in text)

def on_hotkey_pressed():
    # Save original clipboard
    old_clip = pyperclip.paste()
    
    # Simulate Ctrl+C to copy selected text
    pyperclip.copy("")
    keyboard.send("ctrl+c")
    time.sleep(0.08)
    
    selected = pyperclip.paste()
    if not selected:
        print("[Tabdeel] No text selected. Highlight text first.")
        pyperclip.copy(old_clip)
        return
        
    converted = convert_layout(selected)
    pyperclip.copy(converted)
    
    # Paste converted text
    keyboard.send("ctrl+v")
    time.sleep(0.1)
    
    # Restore clipboard
    pyperclip.copy(old_clip)
    print(f"[Tabdeel] Converted successfully!")

print("====================================================")
print("  Tabdeel (تبديل) is running in the background!")
print("  Press [F9] anywhere in Windows to convert text.")
print("====================================================")

keyboard.add_hotkey("f9", on_hotkey_pressed)
keyboard.wait()
